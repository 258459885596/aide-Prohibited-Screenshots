package com.week.floatball;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.support.v7.app.*;
import android.net.*;
import android.view.View.*;
import android.widget.CompoundButton.*;
import android.widget.*;
import android.content.*;
import android.content.pm.*;

public class MainActivity extends AppCompatActivity implements OnClickListener,OnCheckedChangeListener
{
	private boolean Todetermine = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		checkAccessibility();
		Switch mSwitch = (Switch)findViewById(R.id.cardview_itemSwitch);
		mSwitch.setChecked(Todetermine);
		mSwitch.setOnCheckedChangeListener(this);
		findViewById(R.id.mLinearLayout1).setOnClickListener(this);
		findViewById(R.id.mLinearLayout2).setOnClickListener(this);
		findViewById(R.id.mLinearLayout3).setOnClickListener(this);
		findViewById(R.id.mLinearLayout4).setOnClickListener(this);
        if (Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivityForResult(intent, 1);
                Toast.makeText(this, "请先允许FloatBall出现在顶部", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void checkAccessibility() {
        if (!AccessibilityUtil.isAccessibilitySettingsOn(this)) {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            Toast.makeText(this, "请先开启FloatBall辅助功能", Toast.LENGTH_SHORT).show();
        }
    }
	
	@Override
	public void onClick(View p1)
	{
		switch(p1.getId()){
			case R.id.mLinearLayout1:
				Jump("https://www.coolapk.com/apk/com.irozon.sneakersample");
				break;
			case R.id.mLinearLayout2:
				Jump("https://www.coolapk.com/apk/com.irozon.sneakersample.A");
				break;
			case R.id.mLinearLayout3:
				Jump("https://www.taptap.com/app/66282");
				break;
			case R.id.mLinearLayout4:
				Jump("https://www.coolapk.com/apk/com.rmtd.melo.floatingwindow");
				break;
		}
	}
	
	@Override
	public void onCheckedChanged(CompoundButton p1, boolean p2)
	{
		if(Todetermine == true){
			MyAssis.off();
			Todetermine = false;
		}else if(Todetermine == false){
			MyAssis.open();
			Todetermine = true;
		}
	}
	
	public void Jump(String s){
		Uri uri = Uri.parse(s);
		Intent intent = new Intent(Intent.ACTION_VIEW,uri);
		startActivity(intent);
	}
	
}

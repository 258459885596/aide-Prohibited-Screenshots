package com.week.floatball;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import java.io.Serializable;
import java.util.Timer;
import java.util.TimerTask;

public class MyAssis extends AccessibilityService implements Serializable
{
    public static View view;
    public static WindowManager manager;
    public static WindowManager.LayoutParams params;
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event){}

    @Override
    public void onInterrupt(){}

    @Override
    protected void onServiceConnected()
	{
        super.onServiceConnected();
		top_left();
    }

	private void top_left()
	{
		manager = (WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
        params = new WindowManager.LayoutParams();
        params.type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY|
			WindowManager.LayoutParams.FIRST_SYSTEM_WINDOW;
        params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
			WindowManager.LayoutParams.FLAG_SECURE;//FLAG_SECURE 不允许屏幕截图
        params.gravity = Gravity.LEFT | Gravity.TOP;
        params.width = 10;
		params.height = 10;
        params.format = PixelFormat.RGBA_8888;
        view = new MyView(getApplicationContext());
        view.findViewById(R.id.mLinearLayout1).getBackground().setAlpha(0);
        manager.addView(view, params);
        manager.updateViewLayout(view, params);
	}

	public static void open(){
		manager.addView(view,params);
	}

	public static void off(){
		manager.removeView(view);
	}

    @Override
    public void onDestroy()
	{
        manager.removeViewImmediate(view);
        super.onDestroy();
    }

}

package com.week.floatball;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;

public class MyView extends LinearLayout
{
    private View view;
    public MyView(Context context)
	{
        super(context);

        setOrientation(LinearLayout.VERTICAL);
        this.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
											  LayoutParams.MATCH_PARENT));
        view = LayoutInflater.from(context).inflate(R.layout.my_view, null);
        this.addView(view);
    }
}
